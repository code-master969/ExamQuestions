import java.util.Set;

public class CityNetwork {
	
	public static void transform(City origin, int k) {
		//TODO
	}
	
	public static Set<City> getCities(City origin, int k, Set<Integer> sizeSet) {
		return null;
	}
	
}